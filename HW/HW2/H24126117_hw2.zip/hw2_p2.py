range_num=int(input('input a range number: '))
factor=[]
perfect_num=[]
for i in range(2,range_num):
	for j in range(1,i+1):
		if i%j==0:
			factor.append(j)
	if sum(factor)-i==i and sum(factor)/2==i:  #determine whether the number is perfect number or not
		perfect_num.append(i)
	factor.clear()

print('Perfect numbers:')
for i in range(len(perfect_num)):
	print(perfect_num[i])




