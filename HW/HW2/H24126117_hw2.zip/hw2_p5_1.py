num=int(input('Input an integer number: '))
array=[0,1]
for i in range(2,num+1):
	fabo=array[i-2]+array[i-1]
	array.append(fabo)
print('The '+str(num)+'-th Fibonacci sequence number is:'+str(array[num]))