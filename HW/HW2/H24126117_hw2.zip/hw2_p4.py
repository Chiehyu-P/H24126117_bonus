layers=int(input('Enter the number of layers(2 to 5)= '))
length=int(input('Enter the side length of the top layer= '))
growth=int(input('Enter the growth of each layers(2 to 5)= '))
width=int(input('Enter the trunk width(odd number, 3 to 9)= '))
height=int(input('Enter the trunk height(4 to 10)= '))

def large(l):	
	#印單行的空格和符號
	for i in range(1,l+1):
		if l!=length and i==1:
			continue
		#印空格
		print((length+(layers-1)*growth-i)*' ',end='')
		#印符號
		for j in range(1,2*i):
			if j==1 or j==2*i-1 or i==l:	
				print('#',end='')
			else:
				print('@',end='')
		print('\n',end='')

for k in range(1,layers+1):
	large(length+(k-1)*growth)

for i in range(1,height+1):
	print(int((length+(layers-1)*growth)-width/2)*' ',end='')
	print(width*'|')
# large(7)
# large(10)



 